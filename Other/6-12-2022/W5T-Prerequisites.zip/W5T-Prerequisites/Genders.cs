﻿public enum Gender
{
    Female = 0,
    Male = 1,
    Unknown = 2
}